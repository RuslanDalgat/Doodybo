# DoobyDo Bot

Autonomous Telegram bot that reminds you of tasks using GPT and natural language input.